Exemplo Tags:

begin
  Application.Initialize;
  IntegratorSendCustomTags('appName:Demo,appVersion:1.0-SNAPSHOT,clientId:198423');


Exemplo Habilita/Desabilita:

procedure TMainForm.cbMetricsChange(Sender: TObject);
begin
  if cbMetrics.ItemIndex = 0 then
    IntegratorSendEnableSign(true)
  else
    IntegratorSendEnableSign(false);
end;
