Instalação do Java 17:
- Descompactar o arquivo "jdk-17.0.8_windows-x64_bin.zip" em "C:\Program Files\Java", de modo que o caminho fique "C:\Program Files\Java\jdk-17.0.8"
- Configurar as variáveis de ambiente, conforme segue:
  JAVA_HOME -> C:\Program Files\Java\jdk-17.0.8
  CLASSPATH -> .;%JAVA_HOME%\lib
  Path -> %JAVA_HOME%\bin

Instrumentação da aplicação Delphi:
- Instrumentar o código Delphi com a aplicação "BWIntegrator.exe" (abrir com ela o .dpr)
- Incluir no projeto Delphi instrumentado, o arquivo "bwIntegrator.pas"
- Recompilar a aplicação

Cópia de arquivos:
- Unificar num mesmo diretório os arquivos:
  BWIntegrator.exe
  BWIntegrator*.jar
  bwIntegrator.ini
  bwIntegrator.gpt (gerado pelo instrumentador)

Execução:
- Acionar o executável gerado pela recompilação da aplicação instrumentada (BWIntegrator.exe)

