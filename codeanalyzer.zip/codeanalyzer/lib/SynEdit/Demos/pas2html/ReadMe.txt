pas2html.dpr
------------

- Needs Delphi 2 or higher.
- This is a commandline app that reads Object Pascal source code from the
  clipboard, exports it to HTML, and puts the result back to the clipboard.  The
  exported source code can then be pasted into a HTML editor.  It uses the
  syntax highlighting settings of the highest Delphi version installed. 

